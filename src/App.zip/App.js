import React, {useEffect} from 'react';
import { GoogleLogin } from '@react-oauth/google';
import {jwtDecode} from 'jwt-decode';
import raw from './encrypted_emails.txt';


function App() {
  const responseMessage = (response) => {
		console.log(response);
		const token = response?.credential;
			if (token) {
			const decoded = jwtDecode(token);
			console.log('user email: ', decoded.email)
		}
	};

	const errorMessage = (error) => {
		console.log(error);
	};
	
  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(raw);
        const text = await response.text();
        const lines = text.split('\n');

        // Loop through each line and decode
        lines.forEach((line) => {
          try {
            const decoded = jwtDecode(line);
            console.log('List of emails:', decoded.email);
          } catch (error) {
            console.error('Invalid token:', line);
          }
        });
      } catch (error) {
        console.error('Error reading or decoding file:', error);
      }
    };
		fetchData();
  }, []); 


	return (
		<div>
				<h2>Login with your google</h2>
				<br />
				<br />
				<GoogleLogin onSuccess={responseMessage} onError={errorMessage} />
		</div>
	)
}
export default App;